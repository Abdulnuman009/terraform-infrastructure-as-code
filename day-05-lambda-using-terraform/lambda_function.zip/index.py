import json


def handler(event, context):
    print("Received event:", json.dumps(event))

    return {
        "statusCode": 200,
        "body": json.dumps({
            "message": "Hello from Terraform Lambda, i have updated!"
        })
    }